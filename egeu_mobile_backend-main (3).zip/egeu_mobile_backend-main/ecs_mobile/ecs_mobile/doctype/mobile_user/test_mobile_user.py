# Copyright (c) 2021, ERPCloud.Systems and Contributors
# See license.txt

# import frappe
import unittest

class TestMobileUser(unittest.TestCase):
	pass
