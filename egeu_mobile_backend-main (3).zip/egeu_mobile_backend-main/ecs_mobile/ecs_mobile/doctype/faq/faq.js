// Copyright (c) 2023, ERPCloud.Systems and contributors
// For license information, please see license.txt

frappe.ui.form.on('FAQ', {
	// refresh: function(frm) {

	// }
});
