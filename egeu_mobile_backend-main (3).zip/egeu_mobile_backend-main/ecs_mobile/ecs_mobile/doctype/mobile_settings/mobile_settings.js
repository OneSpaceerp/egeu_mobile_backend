// Copyright (c) 2022, ERPCloud.Systems and contributors
// For license information, please see license.txt

frappe.ui.form.on('Mobile Settings', {
	// refresh: function(frm) {

	// }
});
