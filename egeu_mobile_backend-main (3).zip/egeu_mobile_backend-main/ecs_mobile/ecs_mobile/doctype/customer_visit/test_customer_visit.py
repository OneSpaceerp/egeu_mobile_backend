# Copyright (c) 2022, ERPCloud.Systems and Contributors
# See license.txt

# import frappe
import unittest

class TestCustomerVisit(unittest.TestCase):
	pass
